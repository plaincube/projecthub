﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace SetupWrapper
{
    public partial class Form1 : Form
    {
        string installed = "no";
        public Form1()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://github.com/plaincube/projecthub/tree/main/Frameworks%20and%20Bundles%20(.exe%20-%20.bat)/CubedInstaller");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://github.com/plaincube/projecthub/tree/main/Frameworks%20and%20Bundles%20(.exe%20-%20.bat)/CubedInstaller");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://github.com/plaincube/projecthub/tree/main/Frameworks%20and%20Bundles%20(.exe%20-%20.bat)/CubedInstaller");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            textBox2.Text = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
            if (form1.installed == "no")
            {
                textBox2.Text = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
                string FileName = textBox2.Text;
                if (!Directory.Exists(textBox1.Text)) { Directory.CreateDirectory(textBox1.Text); }

                //Set the Executable Name
                string execName = "CubedInstaller.exe";

                string sourceFile = FileName;
                string destFile = textBox1.Text + @"\" + execName;
                File.Copy(sourceFile, destFile, true);

                //Here's where to add additional scripts
                string fullPath = Directory.GetCurrentDirectory() + @"\setup.bat";
                using (StreamWriter writer = new StreamWriter(fullPath))
                {
                    writer.WriteLine(@"@echo off");
                    writer.WriteLine("copy " + execName + ".config" + " \x22" + destFile + ".config\x22");
                }
                System.Diagnostics.Process.Start("setup.bat");

                //Add to startup
                if (checkBox1.Checked == true)
                {
                    string startupFolder = Environment.GetEnvironmentVariable("appdata") + @"\Microsoft\Windows\Start Menu\Programs\Startup\" + execName;
                    textBox2.Text = startupFolder;
                    File.Copy(sourceFile, startupFolder, true);
                }
                form1.installed = "yes";
                MessageBox.Show("Installation complete!");
                checkBox1.Enabled = false;
                textBox1.Enabled = false;
                form1.installed = "yes";
            }
            else if (form1.installed == "yes")
            {
                MessageBox.Show("Already installed, uninstall to continue.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            if (textBox1.Enabled == false) {
                Directory.Delete(textBox1.Text, true);

                if (checkBox1.Checked == true) {
                    string execName = "CubedInstaller.exe";
                    string startupFile = Environment.GetEnvironmentVariable("appdata") + @"\Microsoft\Windows\Start Menu\Programs\Startup\" + execName;
                    File.Delete(startupFile);
                    File.Delete(execName + ".config");
                }
                checkBox1.Enabled = true;
                textBox1.Enabled = true;
                MessageBox.Show("Uninstalled!");

                string setupBat = Directory.GetCurrentDirectory() + @"\setup.bat";
                File.Delete(setupBat);
            } else {
                MessageBox.Show("Not installed!");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            string execName = "CubedInstaller.exe";
            string startupFolder = Environment.GetEnvironmentVariable("appdata") + @"\Microsoft\Windows\Start Menu\Programs\Startup\" + execName;
            textBox2.Text = startupFolder;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discord.gg/JVsvNkgtvm");
        }
    }
}
